package pe.gob.pj.expedientejudicial.usecase;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import pe.gob.pj.expedientejudicial.domain.model.suprema.DetallePartes;
import pe.gob.pj.expedientejudicial.domain.model.suprema.DetalleSuprema;
import pe.gob.pj.expedientejudicial.domain.model.suprema.HitoExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.LinkEjecutoria;
import pe.gob.pj.expedientejudicial.domain.model.suprema.MovimientoInterinstitucional;
import pe.gob.pj.expedientejudicial.domain.model.suprema.NotificacionExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.Resolucion;
import pe.gob.pj.expedientejudicial.domain.model.suprema.ResumenExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.SeguimientoExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.EjecutoriaSuprema;
import pe.gob.pj.expedientejudicial.domain.model.suprema.VistaCausaExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.VocalPonente;
import pe.gob.pj.expedientejudicial.domain.port.persistence.SupremaPersistencePort;
import pe.gob.pj.expedientejudicial.domain.port.usecase.SupremaUseCasePort;


@Service("supremaUseCasePort")
public class SupremaUseCaseAdapter implements SupremaUseCasePort{

	private final SupremaPersistencePort supremaPersistence;

	public SupremaUseCaseAdapter(SupremaPersistencePort supremaPersistence) {
		this.supremaPersistence = supremaPersistence;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<HitoExpediente> obtenerHitosExpediente(String cuo,Long numeroUnico, Integer numeroIncidente, char flagIndicador) throws Exception{
		List<HitoExpediente> hitosExpediente = new ArrayList<>();
		try {
			hitosExpediente = supremaPersistence.obtenerHitosExpediente(cuo,numeroUnico, numeroIncidente, flagIndicador);
		} catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return hitosExpediente;
			}
			throw e;
		}
		return hitosExpediente;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<MovimientoInterinstitucional> obtenerMovimientosInterinstitucionales(String cuo, Long numeroUnico,
			Integer numeroIncidente) throws Exception {
		List<MovimientoInterinstitucional> movimientosInterinstitucional = new ArrayList<>();
		try {
			movimientosInterinstitucional=supremaPersistence.obtenerMovimientosInterinstitucionales(cuo, numeroUnico, numeroIncidente);
		} catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return movimientosInterinstitucional;
			}
			throw e;
		}
		return movimientosInterinstitucional;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<ResumenExpediente> obtenerResumenExpediente(	String cuo, 
																String codigoInstancia,
																String codigoDistrito, 
																String codigoProvincia, 
																String codigoMotivoIngreso, 
																String anioExpediente,
																Long numeroExpedienteSala, 
																String anioProceso, 
																Long numeroExpedienteProceso, 
																String codigoDistritoProceso,
																String apellidoPaterno, 
																String apellidoMaterno, 
																String nombres) throws Exception {

		List<ResumenExpediente> resumenExpediente = new ArrayList<>();
		try {
			resumenExpediente = supremaPersistence.obtenerResumenExpediente(cuo, codigoInstancia, codigoDistrito, codigoProvincia, codigoMotivoIngreso, anioExpediente, numeroExpedienteSala, anioProceso, numeroExpedienteProceso, codigoDistritoProceso, apellidoPaterno, apellidoMaterno, nombres);
		} catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return resumenExpediente;
			}
			throw e;
		}
		return resumenExpediente;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<DetalleSuprema> obtenerDetalleSuprema(String cuo, Long numeroUnico,Integer numeroIncidente) throws Exception {
		List<DetalleSuprema> detalleSuprema = new ArrayList<>();
		try {
				detalleSuprema = supremaPersistence.obtenerDetalleSuprema(cuo, numeroUnico, numeroIncidente);
		} catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return detalleSuprema;
			}
			throw e;
		}
		return detalleSuprema;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<DetallePartes> obtenerDetallePartes(String cuo, Long numeroUnico,Integer numeroIncidente) throws Exception {
		List<DetallePartes> detallePartes = new ArrayList<>();
		try {
				detallePartes = supremaPersistence.obtenerDetallePartes(cuo, numeroUnico, numeroIncidente);
		} catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return detallePartes;
			}
			throw e;
		}
		return detallePartes;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<VistaCausaExpediente> listarVistaCausaExp(String cuo, Long numeroUnico,Integer numeroIncidente) throws Exception {
		List<VistaCausaExpediente> vistaCausaExpediente = new ArrayList<>();
		try {
				vistaCausaExpediente = supremaPersistence.listarVistaCausaExp(cuo, numeroUnico, numeroIncidente);

		}catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return vistaCausaExpediente;
			}
			throw e;
		}
		return vistaCausaExpediente;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<SeguimientoExpediente> obtenerSeguimientoExpediente(String cuo, Long numeroUnico,Integer numeroIncidente)
			throws Exception {
		List<SeguimientoExpediente> seguimientoExpediente = new ArrayList<>();
		try {
			seguimientoExpediente =	supremaPersistence.obtenerSeguimientoExpediente(cuo, numeroUnico, numeroIncidente);
		} catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return seguimientoExpediente;
			}
			throw e;
		}
		return seguimientoExpediente;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<NotificacionExpediente> obtenerNotificacionExpediente(String cuo, Long numeroUnico,Integer numeroIncidente,
			String parametro3, String parametro4) throws Exception {
		List <NotificacionExpediente> notificacionExpediente = new ArrayList<>();
		try {
				notificacionExpediente = supremaPersistence.obtenerNotificacionExpediente(cuo, numeroUnico, numeroIncidente, parametro3, parametro4);
		} catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return notificacionExpediente;
			}
			throw e;
		}
		return notificacionExpediente;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<VocalPonente> obtenerVocalPonente(String cuo, Long numeroUnico,Integer numeroIncidente) throws Exception {
		List<VocalPonente> vocalPonente = new ArrayList<>();
		try {
			vocalPonente = supremaPersistence.obtenerVocalPonente(cuo, numeroUnico, numeroIncidente);
		} catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return vocalPonente;
			}
			throw e;
		}
		return vocalPonente;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public LinkEjecutoria obtenerLinkEjecutoria(String cuo, Long numeroUnico,Integer numeroIncidente, String fechaDescargo)
			throws Exception {
		return supremaPersistence.obtenerLinkEjecutoria(cuo, numeroUnico, numeroIncidente, fechaDescargo);
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public List<EjecutoriaSuprema> obtenerEjecutoriaSuprema(String cuo, Long numeroUnico, Integer numeroIncidente) 
			throws Exception {
		List<EjecutoriaSuprema> ejecutoriaSuprema = new ArrayList<>();
		try {
			ejecutoriaSuprema = supremaPersistence.obtenerEjecutoriaSuprema(cuo, numeroUnico, numeroIncidente);
		}catch (Exception e) {
			if (e.getMessage().contains("JZ0R2")){
				return ejecutoriaSuprema;
			}
			throw e;
		}
		return ejecutoriaSuprema;
	}

	@Override
	@Transactional(transactionManager = "txManagerSuprema", propagation = Propagation.REQUIRES_NEW, readOnly = true, rollbackFor = { Exception.class, SQLException.class})
	public Resolucion obtenerResolucion(String cuo, Long numeroUnico, Integer numeroIncidente, String fechaDescargo)
			throws Exception {
		return supremaPersistence.obtenerResolucion(cuo, numeroUnico, numeroIncidente, fechaDescargo);
	}

}

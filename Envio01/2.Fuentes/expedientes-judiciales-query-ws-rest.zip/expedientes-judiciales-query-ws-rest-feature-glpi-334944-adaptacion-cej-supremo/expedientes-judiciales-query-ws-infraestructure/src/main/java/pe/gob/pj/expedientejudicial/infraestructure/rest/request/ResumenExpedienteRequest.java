package pe.gob.pj.expedientejudicial.infraestructure.rest.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import pe.gob.pj.expedientejudicial.domain.utils.ProjectConstants;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ResumenExpedienteRequest {
	@NotNull(message = "El codigoInstancia no puede ser nulo ")
	@NotBlank(message = "El codigoInstancia no tiene el formato adecuado ")
	@Size(max = 6, message="el codigoInstancia no debe superar 6 caracteres")
    String codigoInstancia;

	@NotNull(message = "El codigoDistrito no puede ser nulo ")
	@NotBlank(message = "El codigoDistrito no tiene el formato adecuado ")
    @Size(max = 6, message="el parametro distritoJudicial no debe superar 6 caracteres")
    String codigoDistrito;

	@NotNull(message = "El codigoProvincia no puede ser nulo ")
	@NotBlank(message = "El codigoProvincia no tiene el formato adecuado ")
    @Size(max = 6, message="el parametro distritoJudicial no debe superar 6 caracteres")
    String codigoProvincia;

    @Size(max = 3, message="el parametro distritoJudicial no debe superar 3 caracteres")
    String codigoMotivoIngreso;
    
    @Pattern(regexp = ProjectConstants.Pattern.ANIO, message="el anioExpediente no tiene el formato [aaaa]")
    String anioExpediente;

    
     Long numeroExpedienteSala;

    @Pattern(regexp = ProjectConstants.Pattern.ANIO, message="el anioProceso no tiene el formato [aaaa]")
    String anioProceso;

    
     Long numeroExpedienteProceso;

    @Size(max = 6, message="el  distritoJudicial no debe superar 6 caracteres")
    String codigoDistritoProceso;

    @Size(max = 200, message="el  distritoJudicial no debe superar los 200 caracteres")
    String apellidoPaterno;

    @Size(max = 100, message="el  distritoJudicial no debe superar los 100 caracteres")
    String apellidoMaterno;

    @Size(max = 40, message="el  distritoJudicial no debe superar los 40 caracteres")
    String nombres;
    
    AuditoriaRequest auditoria;
    
}

package pe.gob.pj.expedientejudicial.infraestructure.rest.request;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;

@Data
@EqualsAndHashCode(callSuper = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
public class HitosExpedienteRequest extends SupremaGeneralRequest{
	
	@NotNull(message="flagIndicador no puede ser nulo")
	char flagIndicador; 
}

package pe.gob.pj.expedientejudicial.infraestructure.rest;

import pe.gob.pj.expedientejudicial.domain.exceptions.ErrorException;
import pe.gob.pj.expedientejudicial.infraestructure.rest.response.GlobalResponse;
import pe.gob.pj.expedientejudicial.infraestructure.utils.UtilInfraestructure;

public interface Base {

	public default void handleException(String cuo, ErrorException e, GlobalResponse res) {
		res.setCodigo(e.getCodigo());
		res.setDescripcion(e.getDescripcion());
		UtilInfraestructure.handleException(cuo, e, e.getCodigo(), e.getDescripcion());
	}
	
}

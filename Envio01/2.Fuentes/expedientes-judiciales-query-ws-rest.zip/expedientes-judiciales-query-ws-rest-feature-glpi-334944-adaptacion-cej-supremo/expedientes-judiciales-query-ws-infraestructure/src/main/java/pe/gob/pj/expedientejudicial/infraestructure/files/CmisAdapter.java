package pe.gob.pj.expedientejudicial.infraestructure.files;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.chemistry.opencmis.client.api.QueryResult;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.data.PropertyData;
import org.apache.chemistry.opencmis.commons.enums.BindingType;
import org.apache.chemistry.opencmis.commons.exceptions.CmisConnectionException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisPermissionDeniedException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisRuntimeException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisUnauthorizedException;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import pe.gob.pj.expedientejudicial.domain.port.files.CmisPort;
import pe.gob.pj.expedientejudicial.domain.utils.ProjectConstants;
import pe.gob.pj.expedientejudicial.domain.utils.file.CMISFileProperties;


@Slf4j
@Component("cmisPort")
public class CmisAdapter implements CmisPort {

	private String atompubUrl41 = "alfresco/cmisatom";
	private String atompubUrl42 = "alfresco/api/-default-/public/cmis/versions/1.0/atom";
	private String rootFolder = "default";
	
    private Session session;
    
    Map<String, String> credencialesConexion = new HashMap<String, String>();
    private String cuo = "default";
	
	@Override
	public void inicializarCredenciales(String host, String puerto, String usuario, String clave, String path,
			String version) throws Exception {
		credencialesConexion.put(SessionParameter.ATOMPUB_URL, "http://"+ host +":"+ puerto +"/" + (version.equals(ProjectConstants.Alfresco.VERSION_4_1)?this.atompubUrl41 : this.atompubUrl42));
		credencialesConexion.put(SessionParameter.USER, usuario);
    	credencialesConexion.put(SessionParameter.PASSWORD, clave);
    	credencialesConexion.put(SessionParameter.BINDING_TYPE, BindingType.ATOMPUB.value());
    	this.rootFolder=path;
	}

	@Override
	public String cmisCreateFolder(String path, String newFolderName) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String cmisCreateFolder(String newFolderName) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean cmisExistsFolder(String path) throws Exception {
		Session session = null;
        Boolean exist = new Boolean(false);
        try{
            session = openSession();
            CmisObject object = session.getObjectByPath(path);
            if (object!=null && ((Folder) object).getPath().equals(path)){
                exist = true;
            }
        }catch(CmisObjectNotFoundException e ){
            return false;
        }catch (Exception e){
            throw  e;
        }
        finally {
            if(null != session){session.clear();}
            finalizeSession();
        }
        return exist;
	}

	@Override
	public String cmisUploadFile(CMISFileProperties fp, ByteArrayInputStream sourceFile, String fileName,
			String destPath, String mimetype, long fileSize) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String cmisUploadFile(String cuo, CMISFileProperties fp, InputStream inputFile, String path, String nameFile,
			String mimetype) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String cmisUploadFile(CMISFileProperties fp, byte[] sourceFile, String fileName, String destPath,
			String mimetype) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String cmisUploadFile(CMISFileProperties fp, String sourceFile, String fileName, String destPath,
			String mimetype) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String cmisGetFile(String fileName, String fileDest) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String cmisGetFile(String fileName, String fileDest, boolean exist, boolean exist1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<String> cmisGetFolderContents(String subFolder) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean cmisDeleteFile(String destPath) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean cmisDeleteFile(String destPath, String name) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean cmisExistFile(String destPath, String name) throws Exception {
		Session session = null;
        Boolean exist = false;
        try {
            session = openSession();
            CmisObject object = session.getObjectByPath(destPath + "/" + name);
            if (object != null) {
                exist = true;
            }

            return exist;

        } catch (CmisObjectNotFoundException e) {
            throw new Exception(e.getMessage(),e.getCause());
        }catch (Exception e){
            throw new Exception(e.getMessage(),e.getCause());
        }
        finally {
            if(null != session){session.clear();}
            finalizeSession();
        }
	}

	@Override
	public Object cmisFindDocument(String destPath, String name) throws Exception {
		 	Session session = null;
	        CmisObject object = null;

	        try {
	            session = openSession();
	            object = session.getObjectByPath(destPath + "/" + name);
	            if (object != null) {
	                return object;
	            }
	        } catch (CmisObjectNotFoundException e) {
	            return false;
	        } catch (Exception e){
	            throw new Exception(e.getMessage(),e.getCause());
	        }
	        finally {
	            if (null != session ){session.clear();}
	            finalizeSession();
	        }
	        return object;
	}

	@Override
	public String cmisUpdateDocument(CMISFileProperties fp, String sourceFile, String fileName, String destPath,
			String mimetype) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFilePath(String docId) throws Exception {
		Session session = null;

        try {
            session = openSession();
            CmisObject object = session.getObject(docId);
            if (object == null) {
                return "";
            }
            return ((Document)object).getPaths().get(0);
        } catch (CmisObjectNotFoundException e) {
            System.out.println(e.getMessage());
            return "";
        }catch (Exception e){
            throw new Exception(e.getMessage(), e.getCause());
        }
        finally {
            if (null != session){session.clear();}
            finalizeSession();
        }
	}

	@Override
	public byte[] getFileByUuid(String docId) throws Exception {
		Session session = null;
        byte[] respuesta=null;
        try {
            session = openSession();
            String cmisObjectId = "workspace://SpacesStore/" + docId;
            CmisObject object = session.getObject(cmisObjectId);
            if(object!=null) {
            	Document doc = (Document) session.getObject(cmisObjectId);
            	Document latestVersion = doc.getObjectOfLatestVersion(false);
                ContentStream contentStream = latestVersion.getContentStream();
                
                if (contentStream != null) {
                    respuesta=inputStreamToBytes(contentStream.getStream());
                    log.info("{} Se descargo de manera correcta de alfresco({}) el documento: {}",cuo,docId,doc.getName());
                } else {
                    log.warn("{} El documento {} descargado de alfresco({}) no tiene contenido.",cuo,doc.getName(),docId);
                }
            }
        } catch (CmisObjectNotFoundException e) {
        	log.error("{} No se encontro en alfresco el objeto: {} (CmisObjectNotFoundException : {})",cuo,docId,e);
        	throw e;
        } catch (CmisConnectionException | CmisUnauthorizedException | CmisPermissionDeniedException e ) {
        	throw e;
        } catch(CmisRuntimeException e) {
        	throw e;
        } catch (Exception e){
        	log.error("{} Error al obtener de alfresco el objeto con uuid: {} (Exception : {})",cuo,docId,e);
        	throw e;
        } finally{
            if (null != session){session.clear();}
            finalizeSession();
        }
        return respuesta;
	}

	@Override
	public Map<String, Object> executeQuery(String query) throws Exception {
		 Map<String, Object> mapProperties = new HashMap<>();
	        Session session = null;
	        try{

	            session = openSession();
	            ItemIterable<QueryResult> results = session.query(query, false);

	            for(QueryResult hit: results) {
	                for(PropertyData<?> property: hit.getProperties()){
	                    String queryName = property.getQueryName();
	                    Object value = property.getFirstValue();
	                    if(null != value){
	                        mapProperties.put(queryName, value);
	                    }
	                }
	            }

	            if(mapProperties.isEmpty()){
	                mapProperties = null;
	            }

	            return mapProperties;
	        }catch (Exception e){
	            throw new Exception(e.getMessage(), e.getCause());
	        }finally{
	            if (null != session){session.clear();}
	            finalizeSession();
	        }
	}

	@Override
	public void createFolferIfNotExist(String path, String newNameFolder) throws Exception {
		// TODO Auto-generated method stub

	}

	    @Override
	    public Session openSession(){
	        if(null == this.session){
	            Map<String, String> parameter =  this.credencialesConexion;
	            SessionFactory sessionFactory = SessionFactoryImpl.newInstance();
	            List<Repository> repositories = sessionFactory.getRepositories(parameter);
	            session = repositories.get(0).createSession();
	        }
	        return session;
	    }
	    
	    @Override
	    public void finalizeSession(){
	        if(null != this.session){
	            this.session.clear();
	            this.session = null;
	        }
	    }

	    public static byte[] inputStreamToBytes(InputStream in) throws Exception {
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(1024);
	        byte[] bytes = new byte[512];
	        int readBytes;
	        try {

	            while ((readBytes = in.read(bytes)) > 0) {
	                outputStream.write(bytes, 0, readBytes);
	            }

	            byte[] byteData = outputStream.toByteArray();
	            outputStream.close();
	            return byteData;

	        } catch (IOException e) {
	            throw new Exception(e.getMessage(), e.getCause());
	        } catch (Exception e){
	            throw new Exception(e.getMessage(), e.getCause());
	        }

	    }
	    
	    
	
}

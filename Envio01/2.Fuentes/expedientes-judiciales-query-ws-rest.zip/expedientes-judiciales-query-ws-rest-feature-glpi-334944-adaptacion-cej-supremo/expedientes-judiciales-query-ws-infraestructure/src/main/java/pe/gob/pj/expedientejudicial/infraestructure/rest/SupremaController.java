package pe.gob.pj.expedientejudicial.infraestructure.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.gob.pj.expedientejudicial.domain.enums.Errors;
import pe.gob.pj.expedientejudicial.domain.enums.Proceso;
import pe.gob.pj.expedientejudicial.domain.exceptions.ErrorAlfrescoException;
import pe.gob.pj.expedientejudicial.domain.exceptions.ErrorDaoException;
import pe.gob.pj.expedientejudicial.domain.exceptions.ErrorException;
import pe.gob.pj.expedientejudicial.domain.model.suprema.DetallePartes;
import pe.gob.pj.expedientejudicial.domain.model.suprema.DetalleSuprema;
import pe.gob.pj.expedientejudicial.domain.model.suprema.EjecutoriaSuprema;
import pe.gob.pj.expedientejudicial.domain.model.suprema.HitoExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.LinkEjecutoria;
import pe.gob.pj.expedientejudicial.domain.model.suprema.MovimientoInterinstitucional;
import pe.gob.pj.expedientejudicial.domain.model.suprema.NotificacionExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.Resolucion;
import pe.gob.pj.expedientejudicial.domain.model.suprema.ResumenExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.SeguimientoExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.VistaCausaExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.VocalPonente;
import pe.gob.pj.expedientejudicial.domain.port.usecase.SupremaUseCasePort;
import pe.gob.pj.expedientejudicial.domain.utils.ProjectConstants;
import pe.gob.pj.expedientejudicial.domain.utils.ProjectUtils;
import pe.gob.pj.expedientejudicial.infraestructure.rest.request.HitosExpedienteRequest;
import pe.gob.pj.expedientejudicial.infraestructure.rest.request.LinkEjecutoriaRequest;
import pe.gob.pj.expedientejudicial.infraestructure.rest.request.NotificacionExpedienteRequest;
import pe.gob.pj.expedientejudicial.infraestructure.rest.request.ResumenExpedienteRequest;
import pe.gob.pj.expedientejudicial.infraestructure.rest.request.SupremaGeneralRequest;
import pe.gob.pj.expedientejudicial.infraestructure.rest.response.GlobalResponse;

@RestController
@RequestMapping(value="/suprema")
public class SupremaController implements Base{
	
	@Autowired
	private SupremaUseCasePort supremaService;
	
	@PostMapping(value="/hitos-expediente")
	public ResponseEntity<GlobalResponse> listarHitosExpedientes(@RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,@Validated @RequestBody HitosExpedienteRequest hitosExpedienteRequest){
		GlobalResponse res = new GlobalResponse();
		res.setCodigoOperacion(cuo);
		try {
			List<HitoExpediente> hitosExpediente = supremaService.obtenerHitosExpediente(cuo, hitosExpedienteRequest.getNumeroUnico(), hitosExpedienteRequest.getNumeroIncidente(), hitosExpedienteRequest.getFlagIndicador());
			if( ProjectUtils.isNullOrEmpty(hitosExpediente)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(hitosExpediente);
			}
		}catch (Exception e){
			handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
		}
		
		return new ResponseEntity<GlobalResponse>(res,HttpStatus.OK);
	}
	
	@PostMapping(value="/movimientos-interinstitucionales")
	public ResponseEntity<GlobalResponse> listarMovimientosInterinstitucionales(@RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo, @Validated @RequestBody SupremaGeneralRequest supremaGeneralRequest){
		GlobalResponse res = new GlobalResponse();
		res.setCodigoOperacion(cuo);
		try {
			List<MovimientoInterinstitucional> movimientosInter = supremaService.obtenerMovimientosInterinstitucionales(cuo, supremaGeneralRequest.getNumeroUnico(), supremaGeneralRequest.getNumeroIncidente());
			if( ProjectUtils.isNullOrEmpty(movimientosInter)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(movimientosInter);
			}
		}catch (Exception e){
			handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
		}
		
		return new ResponseEntity<GlobalResponse>(res,HttpStatus.OK);
	}
	
	@PostMapping(value="/lista-resumen-expediente")
	public ResponseEntity<GlobalResponse> listarResumenExpediente(
				@RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
				@Validated @RequestBody ResumenExpedienteRequest resumenExp){
		GlobalResponse res = new GlobalResponse();
		res.setCodigoOperacion(cuo);
		try {
			List<ResumenExpediente> resumenExpediente = supremaService.obtenerResumenExpediente(
					cuo,resumenExp.getCodigoInstancia(), resumenExp.getCodigoDistrito(), resumenExp.getCodigoProvincia(), 
					resumenExp.getCodigoMotivoIngreso(), resumenExp.getAnioExpediente(), resumenExp.getNumeroExpedienteSala(), 
					resumenExp.getAnioProceso(), resumenExp.getNumeroExpedienteProceso(), resumenExp.getCodigoDistritoProceso(), 
					resumenExp.getApellidoPaterno(), resumenExp.getApellidoMaterno(), resumenExp.getNombres()
					);
			if( ProjectUtils.isNullOrEmpty(resumenExpediente)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(resumenExpediente);
			}
		}catch (Exception e){
			handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
		}
		
		return new ResponseEntity<GlobalResponse>(res,HttpStatus.OK);
	}
	
	@PostMapping("/detalle-suprema")
    public ResponseEntity<GlobalResponse> obtenerDetalleSuprema(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody SupremaGeneralRequest suprema) {
        GlobalResponse res = new GlobalResponse();
        res.setCodigoOperacion(cuo);
		 try {
			List<DetalleSuprema> listaDetalleSuprema = supremaService.obtenerDetalleSuprema(cuo, suprema.getNumeroUnico(), suprema.getNumeroIncidente());
			if( ProjectUtils.isNullOrEmpty(listaDetalleSuprema)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(listaDetalleSuprema);
			} 
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
	@PostMapping("/detalle-partes")
    public ResponseEntity<GlobalResponse> obtenerDetallePartes(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody SupremaGeneralRequest suprema) {
        GlobalResponse res = new GlobalResponse();
			res.setCodigoOperacion(cuo);
		 try {
			List<DetallePartes> listaDetallePartes = supremaService.obtenerDetallePartes(cuo, suprema.getNumeroUnico(), suprema.getNumeroIncidente());
			if( ProjectUtils.isNullOrEmpty(listaDetallePartes)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(listaDetallePartes);
			} 
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
	@PostMapping("/seguimiento-expediente")
    public ResponseEntity<GlobalResponse> obtenerSeguimientoExpediente(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody SupremaGeneralRequest suprema) {
        GlobalResponse res = new GlobalResponse();
			res.setCodigoOperacion(cuo);
		 try {
			List<SeguimientoExpediente> listaSeguimientoExpediente = supremaService.obtenerSeguimientoExpediente(cuo, suprema.getNumeroUnico(), suprema.getNumeroIncidente());
			if( ProjectUtils.isNullOrEmpty(listaSeguimientoExpediente)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(listaSeguimientoExpediente);
			} 
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
	
	@PostMapping("/notificacion-expediente")
    public ResponseEntity<GlobalResponse> obtenerNotificacionExpediente(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody NotificacionExpedienteRequest notificacion) {
        GlobalResponse res = new GlobalResponse();
			res.setCodigoOperacion(cuo);
		 try {
			List<NotificacionExpediente> listaNotificacionExpediente = supremaService.obtenerNotificacionExpediente(cuo, notificacion.getNumeroUnico(), 
					notificacion.getNumeroIncidente(), notificacion.getFechaIngreso(),notificacion.getFechaIngresoActo());
			if( ProjectUtils.isNullOrEmpty(listaNotificacionExpediente)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(listaNotificacionExpediente);
			} 
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
	@PostMapping("/vocal-ponente")
    public ResponseEntity<GlobalResponse> obtenerVocalPonente(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody SupremaGeneralRequest suprema) {
        GlobalResponse res = new GlobalResponse();
			res.setCodigoOperacion(cuo);
		 try {
			List<VocalPonente> listaVocalPonente = supremaService.obtenerVocalPonente(cuo, suprema.getNumeroUnico(), suprema.getNumeroIncidente());
			if( ProjectUtils.isNullOrEmpty(listaVocalPonente)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(listaVocalPonente);
			} 
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
	@PostMapping("/link-ejecutoria")
    public ResponseEntity<GlobalResponse> obtenerLinkEjecutoria(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody LinkEjecutoriaRequest link) {
        GlobalResponse res = new GlobalResponse();
			res.setCodigoOperacion(cuo);
		 try {
			LinkEjecutoria linkEjecutoria = supremaService.obtenerLinkEjecutoria(cuo, link.getNumeroUnico(), link.getNumeroIncidente(), link.getFechaDescargo());
			if( ProjectUtils.isNullOrEmpty(linkEjecutoria)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(linkEjecutoria);
			} 
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
	@PostMapping("/obtener-resolucion")
    public ResponseEntity<GlobalResponse> obtenerResolucion(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody LinkEjecutoriaRequest link) {
        GlobalResponse res = new GlobalResponse();
			res.setCodigoOperacion(cuo);
		 try {
			Resolucion resolucion = supremaService.obtenerResolucion(cuo, link.getNumeroUnico(), link.getNumeroIncidente(), link.getFechaDescargo());
			if( !ProjectUtils.isNullOrEmpty(resolucion)) {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(resolucion);
			} 
        } catch (ErrorDaoException e) {
        	handleException(cuo,
					new ErrorException(
							e.getCodigo(),
							e.getDescripcion(), e.getCause()),
					res);
        } catch (ErrorAlfrescoException e) {
        	handleException(cuo,
					new ErrorException(
							e.getCodigo(),
							e.getMessage(), e.getCause()),
					res);
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_AL.getCodigo(), Errors.ERROR_AL.getNombre()
									+Proceso.DESCARGAR_RESOLUCION,
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
	@PostMapping("/vista-causa-expediente")
    public ResponseEntity<GlobalResponse> obtenerVistaCausa(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody SupremaGeneralRequest suprema) {
        GlobalResponse res = new GlobalResponse();
			res.setCodigoOperacion(cuo);
		 try {
			List<VistaCausaExpediente> vistaCausaExpedientes = supremaService.listarVistaCausaExp(cuo, suprema.getNumeroUnico(), suprema.getNumeroIncidente());
			if( ProjectUtils.isNullOrEmpty(vistaCausaExpedientes)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(vistaCausaExpedientes);
			} 
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
	@PostMapping("/lista-ejecutoria")
    public ResponseEntity<GlobalResponse> obtenerEjecutoriaSuprema(
            @RequestAttribute(name = ProjectConstants.AUD_CUO) String cuo,
            @Validated @RequestBody SupremaGeneralRequest suprema) {
        GlobalResponse res = new GlobalResponse();
			res.setCodigoOperacion(cuo);
		 try {
			List<EjecutoriaSuprema> listaEjecutoria= supremaService.obtenerEjecutoriaSuprema(cuo, suprema.getNumeroUnico(), suprema.getNumeroIncidente());
			if( ProjectUtils.isNullOrEmpty(listaEjecutoria)) {
				res.setCodigo(Errors.ERROR_EJECUCION_SP.getCodigo());
				res.setDescripcion(Errors.ERROR_EJECUCION_SP.getNombre());
			}else {
				res.setCodigo(Errors.OPERACION_EXITOSA.getCodigo());
				res.setDescripcion(Errors.OPERACION_EXITOSA.getNombre());
				res.setData(listaEjecutoria);
			} 
        } catch (Exception e) {
        	handleException(cuo,
					new ErrorException(
							Errors.ERROR_EJECUCION_SP.getCodigo(), Errors.ERROR_AL.getNombre()
									+ Proceso.CONSULTAR_SP.getNombre() + Errors.ERROR_EJECUCION_SP.getNombre(),
							e.getMessage(), e.getCause()),
					res);
        }
		 return new ResponseEntity<>(res, HttpStatus.OK);
    }
	
}

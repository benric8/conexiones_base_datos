package pe.gob.pj.expedientejudicial.infraestructure.db.procedures.suprema;

import java.io.Serializable;

public class ProcedureSuprema implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final String SP_LISTAR_RESUMEN_EXPEDIENTE="exec dbo.usp_ListaResumenExpSuprema(?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String SP_LISTAR_HITOS_EXPEDIENTE="exec dbo.usp_HitosExpedienteSuprema(?,?,?)";
	public static final String SP_LISTAR_MOVIMIENTOS_INTERINSTITUCIONALES="exec dbo.usp_MovimientosInterSuprema(?,?)";
	public static final String SP_OBTIENE_DETALLE_SUPREMA = "exec dbo.usp_DetalleExpedienteSuprema(?,?)";
	public static final String SP_OBTIENE_DETALLE_PARTES = "exec dbo.usp_DetallePartesSuprema(?,?)";
	public static final String SP_LISTA_VISTA_CAUSA_EXP = "exec dbo.usp_VistaCausaSuprema(?,?)";
	public static final String SP_SEGUIMIENTO_EXPEDIENTE = "exec dbo.usp_SeguimientoExpSuprema(?,?)";
	public static final String SP_NOTIFICACION_EXPEDIENTE = "exec dbo.usp_NotificacionExpSuprema(?,?,?,?)";
	public static final String SP_OBTIENE_VOCAL_PONENTE = "exec dbo.usp_VocalPonenteSuprema(?,?)";
	public static final String SP_OBTIENE_LINK_EJECUTORIA = "exec dbo.usp_LinkEjecutoriaSuprema(?,?,?)";
	public static final String SP_LISTA_EJECUTORIA_SUPREMA = "exec dbo.usp_ListarEjecutoriaSuprema(?,?)";

}

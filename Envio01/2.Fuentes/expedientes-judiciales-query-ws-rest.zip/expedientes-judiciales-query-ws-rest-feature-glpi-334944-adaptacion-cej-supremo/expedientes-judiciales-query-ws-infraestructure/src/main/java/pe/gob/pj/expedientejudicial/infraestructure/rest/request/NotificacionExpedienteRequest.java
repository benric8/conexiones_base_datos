package pe.gob.pj.expedientejudicial.infraestructure.rest.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.FieldDefaults;
import pe.gob.pj.expedientejudicial.domain.utils.ProjectConstants;

@Data
@EqualsAndHashCode(callSuper = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
public class NotificacionExpedienteRequest extends SupremaGeneralRequest {
	
	@NotNull(message="fechaIngreso no puede ser nulo")
	@Pattern(regexp = ProjectConstants.Pattern.FECHA_YYYY_MM_DD_HH_MM_SS_SSS,message="fechaIngreso no tiene un fomato valido")
	String fechaIngreso;
	
	@NotNull(message="fechaIngresoActo no puede ser nulo")
	@Pattern(regexp = ProjectConstants.Pattern.FECHA_YYYY_MM_DD_HH_MM_SS_SSS,message="fechaIngresoActo no tiene un fomato valido")
	String fechaIngresoActo;
	
}

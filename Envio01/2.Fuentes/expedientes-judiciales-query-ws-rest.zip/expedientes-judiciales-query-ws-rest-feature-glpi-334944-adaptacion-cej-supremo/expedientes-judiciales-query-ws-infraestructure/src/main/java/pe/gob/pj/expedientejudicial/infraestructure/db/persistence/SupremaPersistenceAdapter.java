package pe.gob.pj.expedientejudicial.infraestructure.db.persistence;

import java.io.Serializable;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.apache.chemistry.opencmis.commons.exceptions.CmisBaseException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisConnectionException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisPermissionDeniedException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisUnauthorizedException;
import org.hibernate.exception.SQLGrammarException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import pe.gob.pj.expedientejudicial.domain.enums.Errors;
import pe.gob.pj.expedientejudicial.domain.enums.Proceso;
import pe.gob.pj.expedientejudicial.domain.exceptions.ErrorAlfrescoException;
import pe.gob.pj.expedientejudicial.domain.exceptions.ErrorDaoException;
import pe.gob.pj.expedientejudicial.domain.model.suprema.DetallePartes;
import pe.gob.pj.expedientejudicial.domain.model.suprema.DetalleSuprema;
import pe.gob.pj.expedientejudicial.domain.model.suprema.HitoExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.LinkEjecutoria;
import pe.gob.pj.expedientejudicial.domain.model.suprema.MovimientoInterinstitucional;
import pe.gob.pj.expedientejudicial.domain.model.suprema.NotificacionExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.Resolucion;
import pe.gob.pj.expedientejudicial.domain.model.suprema.ResumenExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.SeguimientoExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.EjecutoriaSuprema;
import pe.gob.pj.expedientejudicial.domain.model.suprema.VistaCausaExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.VocalPonente;
import pe.gob.pj.expedientejudicial.domain.port.files.CmisPort;
import pe.gob.pj.expedientejudicial.domain.port.persistence.SupremaPersistencePort;
import pe.gob.pj.expedientejudicial.domain.utils.ProjectProperties;
import pe.gob.pj.expedientejudicial.infraestructure.db.procedures.suprema.ProcedureSuprema;


@Component("supremaPersistencePort")
public class SupremaPersistenceAdapter implements Serializable, SupremaPersistencePort {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Autowired
	@Qualifier("jdbcTemplateSuprema")
	protected JdbcTemplate jdbcSuprema;
	
	@Autowired
	@Qualifier("cmisPort")
	private CmisPort cmisManager;

	@Override
	public List<HitoExpediente> obtenerHitosExpediente(String cuo, Long numeroUnico, Integer numeroIncidente, char flagIndicador) throws Exception{
		
		List<HitoExpediente> hitosExpediente = new ArrayList<>();
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_LISTAR_HITOS_EXPEDIENTE);
			
			
			
			Object[] params = {numeroUnico,numeroIncidente,flagIndicador};
			int[] tipo = {Types.NUMERIC,Types.INTEGER,Types.CHAR};
			
			hitosExpediente=this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						
						return new HitoExpediente(rs.getInt("c_hito"),
													rs.getString("x_desc_hito"),
													rs.getInt("n_orden"),
													rs.getString("fecha_hito"),
													rs.getString("des_tipo_audiencia"),
													rs.getString("x_desc_estado"),
													rs.getString("c_motivo_ingreso"),
													rs.getString("x_desc_motivo_ingreso"),
													rs.getString("l_ind_ejecutoria"),
													rs.getString("l_ind_fiscalia"),
													rs.getString("x_observacion"),
													rs.getString("tipo"),
													rs.getString("l_cronica")
													);
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
					
			
			
		} catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return hitosExpediente;
		
	}

	@Override
	public List<MovimientoInterinstitucional> obtenerMovimientosInterinstitucionales(String cuo, Long numeroUnico,
			Integer numeroIncidente) throws Exception {
		
		List<MovimientoInterinstitucional> movimientosInterinstitucionales = new ArrayList<MovimientoInterinstitucional>();
		
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_LISTAR_MOVIMIENTOS_INTERINSTITUCIONALES);
			
			
			
			Object[] params = {numeroUnico,numeroIncidente};
			int[] tipo = {Types.NUMERIC,Types.INTEGER};
			
			movimientosInterinstitucionales=this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						
						return new MovimientoInterinstitucional(
													rs.getString("f_ingreso_acto"),
													rs.getString("x_desc_ubicacion"),
													rs.getString("X_SUMILLA")
													
													);
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
					
			
			
		} catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return movimientosInterinstitucionales;
	}

	@Override
	public List<ResumenExpediente> obtenerResumenExpediente(	String cuo, 
																		String codigoInstancia,
																		String codigoDistrito, 
																		String codigoProvincia, 
																		String codigoMotivoIngreso, 
																		String anioExpediente,
																		Long numeroExpedienteSala, 
																		String anioProceso, 
																		Long numeroExpedienteProceso, 
																		String codigoDistritoProceso,
																		String apellidoPaterno, 
																		String apellidoMaterno, 
																		String nombres) throws Exception {
		List<ResumenExpediente>  listaResumenExpediente = new ArrayList<ResumenExpediente>();
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_LISTAR_RESUMEN_EXPEDIENTE);
			
			Object[] params = {codigoInstancia, codigoDistrito, codigoProvincia, codigoMotivoIngreso, anioExpediente, numeroExpedienteSala, anioProceso, numeroExpedienteProceso, codigoDistritoProceso, apellidoPaterno, apellidoMaterno, nombres};
			int[] tipo = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
			
			listaResumenExpediente=this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						
						return new ResumenExpediente(
										rs.getLong("nid_unico"),
										rs.getInt("nid_incidente"),
										rs.getString("f_ingreso"), 
										rs.getString("cod_expediente"),
										rs.getString("txt_instancia"),
										rs.getString("txt_distrito"),
										rs.getString("txt_partes"),
										rs.getString("cod_visualiza"),
										rs.getString("c_org_jurisd"),
										rs.getString("x_cuaderno"),
										rs.getString("c_motivo_ingreso"),
										rs.getString("l_ind_redistribucion"),
										rs.getString("c_instancia_ant")
										);
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
		} catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		return listaResumenExpediente; 
	}

	@Override
	public List<DetalleSuprema> obtenerDetalleSuprema(String cuo, Long numeroUnico,Integer numeroIncidente) throws Exception {
		List<DetalleSuprema> listaDetalleSuprema = new ArrayList<>();
		
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_OBTIENE_DETALLE_SUPREMA);
			
			
			
			Object[] params = {numeroUnico,numeroIncidente};
			int[] tipo = {Types.NUMERIC,Types.INTEGER};
			
			listaDetalleSuprema=this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						
						return new DetalleSuprema(
										rs.getLong("nid_unico"),
										rs.getLong("nid_incidente"),
										rs.getString("cod_expediente"),
										rs.getString("txt_instancia"),
										rs.getString("txt_especialidad"),
										rs.getString("txt_especialista"),
										rs.getString("txt_procedencia"),
										rs.getString("txt_proceso"),
										rs.getString("txt_materia"),
										rs.getString("cod_visualiza"),
										rs.getString("txt_sumilla"),
										rs.getString("txt_etapa"),
										rs.getString("txt_estado"),
										rs.getString("txt_ubicacion"),
										rs.getString("cod_conclusion"),
										rs.getString("fec_inicio"),
										rs.getString("cod_distrito"),
										rs.getString("nro_procedencia"),
										rs.getString("secretario"),
										rs.getString("recurso"),
										rs.getString("delito"),
										rs.getString("organo_procedencia"),
										rs.getString("distrito_procedencia"),
										rs.getString("ind_distribucion"),
										rs.getString("instancia_anterior"),
										rs.getString("cod_motivo_ingreso"),
										rs.getString("cod_instancia"));
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
					
			
			
		} catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return listaDetalleSuprema;
	}

	@Override
	public List<DetallePartes> obtenerDetallePartes(String cuo, Long numeroUnico,Integer numeroIncidente) throws Exception {
		List<DetallePartes> listaDetallePartes = new ArrayList<>();
		
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_OBTIENE_DETALLE_PARTES);
			
			
			
			Object[] params = {numeroUnico,numeroIncidente};
			int[] tipo = {Types.NUMERIC,Types.INTEGER};
			
			listaDetallePartes = this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						return new DetallePartes(
								rs.getLong("nid_unico"),
								rs.getLong("nid_incidente"),
								rs.getString("x_ape_paterno"),
								rs.getString("x_ape_materno"),
								rs.getString("x_nombres"),
								rs.getString("x_desc_parte"),
								rs.getString("x_desc_tipo_persona"),
								rs.getString("c_cod_visualiza"),
								rs.getString("l_recurrente"));
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
					
			
			
		} catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return listaDetallePartes;
	}

	@Override
	public List<VistaCausaExpediente> listarVistaCausaExp(String cuo, Long numeroUnico,Integer numeroIncidente) throws Exception {
		List<VistaCausaExpediente> listaVistaCausaExpediente = new ArrayList<>();
		
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_LISTA_VISTA_CAUSA_EXP);
			Object[] params = {numeroUnico,numeroIncidente};
			int[] tipo = {Types.NUMERIC,Types.INTEGER};
			
			listaVistaCausaExpediente = this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						return new VistaCausaExpediente(
								rs.getLong("n_unico"),
								rs.getLong("n_incidente"),
								rs.getString("f_vista"),
								rs.getString("f_programacion"),
								rs.getString("estado"),
								rs.getString("sentido_fallo"),
								rs.getString("x_nombre_parte"),
								rs.getString("des_tipo_audiencia"),
								rs.getString("observacion")
								);
								
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
			
					
			
			
		} catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return listaVistaCausaExpediente;
	}

	@Override
	public List<SeguimientoExpediente> obtenerSeguimientoExpediente(String cuo, Long numeroUnico,Integer numeroIncidente)
			throws Exception {
		List<SeguimientoExpediente> listaSeguimientoExpediente = new ArrayList<>();
		
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_SEGUIMIENTO_EXPEDIENTE);
			
			
			
			Object[] params = {numeroUnico,numeroIncidente};
			int[] tipo = {Types.NUMERIC,Types.INTEGER};
			
			listaSeguimientoExpediente = this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						
						return new SeguimientoExpediente(
									    rs.getLong("nid_unico"),
									    rs.getLong("nid_incidente"),
									    rs.getString("tip_acto"),
									    rs.getString("flg_visualizacion"),
									    rs.getString("fec_descargo"),
									    rs.getString("cod_tipo_notificacion"),
									    rs.getString("txt_sumilla"),
									    rs.getInt("num_fojas"),
									    rs.getString("fec_ingreso_acto"),
									    rs.getString("txt_resolucion"),
									    rs.getString("flg_fila"),
									    rs.getString("txt_acto"),
									    rs.getString("fec_ingreso"),
									    rs.getString("x_desc_usuario"),
									    rs.getString("n_con_resol"),
									    rs.getString("n_tipo_archivo"),
									    rs.getString("n_con_firma"),
									    rs.getString("fec_resolucion"),
									    rs.getInt("flg_obligatorio"),
									    rs.getInt("ano_grupo_notif"),
									    rs.getLong("sec_grupo_notif"),
									    rs.getString("c_org_jurisd"),
									    rs.getString("flg_utilizacion"),
									    rs.getString("presentante"),
									    rs.getString("flg_tramite"));

			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
					
			
			
		} catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return listaSeguimientoExpediente;
	}

	@Override
	public List<NotificacionExpediente> obtenerNotificacionExpediente(String cuo, Long numeroUnico,Integer numeroIncidente,
			String fechaIngreso, String fechaIngresoActo) throws Exception {
		List<NotificacionExpediente> listaNotificacionExpediente = new ArrayList<>();
		
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_NOTIFICACION_EXPEDIENTE);
			
			
			
			Object[] params = {numeroUnico,numeroIncidente,fechaIngreso,fechaIngresoActo};
			int[] tipo = {Types.NUMERIC,Types.INTEGER,Types.VARCHAR,Types.VARCHAR};
			
			listaNotificacionExpediente = this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						
						return new NotificacionExpediente(
								rs.getLong("nid_unico"),
								rs.getLong("nid_incidente"),
								rs.getLong("num_sec_notificacion"),
								rs.getInt("num_anho"),
								rs.getString("fec_ingreso"),
								rs.getString("fec_ingreso_acto"),
								rs.getString("cod_distrito"),
								rs.getString("cod_provincia"),
								rs.getString("cod_instancia"),
								rs.getString("txt_cedula"),
								rs.getString("fec_descargo"),
								rs.getString("txt_destinatario"),
								rs.getString("est_notificacion"),
								rs.getString("txt_estado"),
								rs.getString("txt_anexos"),
								rs.getString("txt_tipo_ent_notif"),
								rs.getString("fec_impresion"),
								rs.getInt("fec_impresion_dias"),
								rs.getString("fec_envio_central"),
								rs.getInt("fec_envio_dias"),
								rs.getString("fec_recepcion_central"),
								rs.getInt("fec_recepcion_dias"),
								rs.getString("fec_notificacion"),
								rs.getInt("fec_notificacion_dias"),
								rs.getString("fec_devolucion"),
								rs.getInt("fec_devolucion_dias"),
								rs.getString("l_visualizacion"));
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
					
			
			
		}  catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return listaNotificacionExpediente;
	}

	@Override
	public List<VocalPonente> obtenerVocalPonente(String cuo, Long numeroUnico,Integer numeroIncidente) throws Exception {
		List<VocalPonente> listaVocalPonente = new ArrayList<>();
		
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_OBTIENE_VOCAL_PONENTE);
			
			
			
			Object[] params = {numeroUnico,numeroIncidente};
			int[] tipo = {Types.NUMERIC,Types.INTEGER};
			
			listaVocalPonente = this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						
						return new VocalPonente(
								rs.getString("c_usuario"),
							    rs.getString("x_nom_usuario"));
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
					
			
			
		}  catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return listaVocalPonente;
	}

	@Override
	public LinkEjecutoria obtenerLinkEjecutoria(String cuo, Long numeroUnico,Integer numeroIncidente, String fechaDescargo)
			throws Exception {
		LinkEjecutoria linkEjecutoria = new LinkEjecutoria();
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_OBTIENE_LINK_EJECUTORIA);
				
			Object[] params = {numeroUnico,numeroIncidente,fechaDescargo};
			int[] tipo = {Types.NUMERIC,Types.INTEGER,Types.VARCHAR};

		
			linkEjecutoria = jdbcSuprema.queryForObject(
				    sql.toString(), 
				    params, 
				    tipo,
				    (rs, rowNum) -> new LinkEjecutoria(
				        rs.getString("x_comentario_pdf"),
				        rs.getString("f_descargo"),
				        rs.getString("uuid_pdf")
				    )
				);			
			
		}  catch( EmptyResultDataAccessException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_AL.getNombre() +
					Proceso.RECUPERAR_REGISTROS_SP.getNombre()+
					Errors.ERROR_RECUPERAR_REGISTROS.getNombre(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		} catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return linkEjecutoria;
	}
	
	@Override
	public List<EjecutoriaSuprema> obtenerEjecutoriaSuprema(String cuo, Long numeroUnico, Integer numeroIncidente) throws Exception {
		List<EjecutoriaSuprema> uuidEjecutoria = new ArrayList<>();
		
		try {
			jdbcSuprema.execute("SET CHAINED OFF");
			StringBuilder sql = new StringBuilder();
			sql.append(ProcedureSuprema.SP_LISTA_EJECUTORIA_SUPREMA);

			Object[] params = {numeroUnico,numeroIncidente};
			int[] tipo = {Types.NUMERIC,Types.INTEGER};
			
			uuidEjecutoria = this.jdbcSuprema.query(sql.toString(), params, tipo, 
					(rs, rowNum)->{
						
						return new EjecutoriaSuprema(
									rs.getLong("n_unico"),
								 	rs.getInt("n_incidente"),
							        rs.getString("f_descargo"),
							        rs.getString("x_desc_acto_procesal"),
							        rs.getString("x_comentario_pdf"),
							        rs.getString("x_uuid_pdf"));
					
			}).stream().filter(Objects::nonNull).collect(Collectors.toList());
					
			
			
		}  catch(SQLGrammarException | IllegalArgumentException | ConstraintViolationException
				| DataIntegrityViolationException e) { throw new
			ErrorDaoException(Errors.ERROR_EJECUCION_SP.getCodigo(),
					Errors.ERROR_EJECUCION_SP.getNombre() +
					Proceso.CONSULTAR_SP.getNombre() +
					Errors.ERROR_EJECUCION_SP.getCodigo(), jdbcSuprema.getDataSource().getConnection().getMetaData().getURL(), e.getMessage(),
					e.getCause());
		}
		
		return uuidEjecutoria;
	}

	@Override
	public Resolucion obtenerResolucion(String cuo, Long numeroUnico, Integer numeroIncidente, String fechaDescargo)
			throws Exception {
		Resolucion resolucion =new Resolucion();
		LinkEjecutoria linkEjecutoria=new LinkEjecutoria();
		try {

			linkEjecutoria = obtenerLinkEjecutoria(cuo, numeroUnico, numeroIncidente, fechaDescargo);

			String usuarioAlfresco = ProjectProperties.getAlfrescoSupremaUsuario();
			cmisManager.inicializarCredenciales(ProjectProperties.getAlfrescoSupremaHost(), 
					ProjectProperties.getAlfrescoSupremaPuerto(), 
					usuarioAlfresco, 
					ProjectProperties.getAlfrescoSupremaClave(), 
					ProjectProperties.getAlfrescoSupremaPath(), 
					ProjectProperties.getAlfrescoSupremaVersion());
			
			resolucion.setResolucion(cmisManager.getFileByUuid(linkEjecutoria.getUuidPdf()));
			
			
		} catch(CmisConnectionException | CmisUnauthorizedException | CmisPermissionDeniedException | CmisObjectNotFoundException e) {
			throw new ErrorAlfrescoException(Errors.ERROR_ALFRESCO_DESCARGAR_ARCHIVO.getCodigo(),
					Errors.ERROR_AL.getNombre() +
					Proceso.DESCARGAR_RESOLUCION.getNombre()+
					Errors.ERROR_ALFRESCO_DESCARGAR_ARCHIVO.getNombre(),e);
		} catch (CmisBaseException e) {
	        throw new ErrorAlfrescoException(Errors.ERROR_ALFRESCO_DESCARGAR_ARCHIVO.getCodigo(),
	        		Errors.ERROR_AL.getNombre() +
					Proceso.DESCARGAR_RESOLUCION.getNombre()+
					Errors.ERROR_ALFRESCO_DESCARGAR_ARCHIVO.getNombre(),e);
	    }
		
		return resolucion;
	}
	
	
	

}

package pe.gob.pj.expedientejudicial.infraestructure.rest.request;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SupremaGeneralRequest {
	
	@NotNull(message = "El numeroUnico no puede ser null.")
	Long numeroUnico;
	
	@NotNull(message = "El numeroIncidente no puede ser null.")
	Integer numeroIncidente;
	
	AuditoriaRequest auditoria;
}

package pe.gob.pj.expedientejudicial.infraestructure.rest.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import pe.gob.pj.expedientejudicial.domain.utils.ProjectConstants;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AuditoriaRequest {

	@NotBlank(message = "El usuario tiene un valor incorrecto")
	@NotNull(message = "El usuario no puede ser null.")
	@Length(max = 20, message = "El nombre de usuario de red  de solicitante tiene una longitud que ha superado el máximo permitido.")
	@JsonProperty("usuario")
	String usuario;

	@NotBlank(message = "El nombrePc tiene un valor incorrecto.")
	@NotNull(message = "El nombrePc no puede ser null.")
	@Length(max = 20, message = "El nombre de PC tiene una longitud que ha superado el máximo permitido.")
	@JsonProperty("nombrePc")
	String nombrePc;

	@NotBlank(message = "El numeroIp tiene un valor incorrecto")
	@NotNull(message = "El numeroIp no puede ser null")
	@Pattern(regexp = ProjectConstants.Pattern.IP, message = "La IP de solicitante no tiene un formato válido.")
	@Length(max = 15, message = "La IP de solicitante tiene una longitud que ha superado el máximo permitido.")
	@JsonProperty("numeroIp")
	String numeroIp;

	@NotBlank(message = "El direccionMac tiene un valor incorrecto.")
	@NotNull(message = "El direccionMac no puede ser null.")
	@Pattern(regexp = ProjectConstants.Pattern.MAC, message = "La dirección MAC address es incorrecta.")
	@Length(min = 17, max = 17, message = "Dirección MAC address de la PC no tiene una longitud permitida.")
	@JsonProperty("direccionMac")
	String direccionMac;

}

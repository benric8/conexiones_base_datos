package pe.gob.pj.expedientejudicial.infraestructure.dto.suprema;

public class HitosExpedienteDTO {
	
}

const fs = require('fs');
const path = require('path');
const csvWriter = require('csv-writer').createObjectCsvWriter;
const execSync = require('child_process').execSync;

const dir='/d/Proyectos/ws/ws_expedientejudicial/expedientes-judiciales-query-ws-rest';

const getDirectoryFiles = (dir) => {
    let results = [];
    const list = fs.readdirSync(dir);
    list.forEach((file) => {
        file = path.resolve(dir, file);
        const stat = fs.statSync(file);
        if (stat && stat.isDirectory()) {
            results = results.concat(getDirectoryFiles(file));
        } else {
            results.push(file);
        }
    });
    return results;
};

const getAuthor = (filePath) => {
    try {
        const command = `git log --format=%an -n 1 -- "${filePath}"`;
        const author = execSync(command).toString().trim();
        return author || 'Unknown';
    } catch (error) {
        return 'Unknown';
    }
};

const generateCsv = async (dir) => {
    const files = getDirectoryFiles(dir);
    const records = files.map((file) => {
        const stat = fs.statSync(file);
        const extension = path.extname(file);
        const createdAt = stat.birthtime.toISOString();
        const modifiedAt = stat.mtime.toISOString();
        //const author = getAuthor(file);
        return { file, extension, createdAt, modifiedAt };
    });

    const csv = csvWriter({
        path: 'file_details.csv',
        header: [
            { id: 'file', title: 'File' },
            { id: 'extension', title: 'Extension' },
            { id: 'createdAt', title: 'Creation Date' },
            { id: 'modifiedAt', title: 'Modification Date' },
            //{ id: 'author', title: 'Author' },
        ],
    });

    await csv.writeRecords(records);
    console.log('CSV file created: file_details.csv');
};

// Replace '/your/directory/path' with the actual directory path you want to scan
generateCsv(dir);

package pe.gob.pj.expedientejudicial.domain.model.suprema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LinkEjecutoria {
	private String comentarioPdf;
	private String fechaDescargo;
	private String uuidPdf;
}

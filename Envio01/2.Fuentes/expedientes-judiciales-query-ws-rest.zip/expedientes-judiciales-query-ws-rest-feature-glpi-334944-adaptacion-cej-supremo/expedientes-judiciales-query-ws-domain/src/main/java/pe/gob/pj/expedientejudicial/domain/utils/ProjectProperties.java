package pe.gob.pj.expedientejudicial.domain.utils;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@Configuration
@PropertySources(value= {
		@PropertySource("classpath:expedientes-judiciales-query-ws.properties")
})
public class ProjectProperties implements Serializable {

    private static final long serialVersionUID = 1L;

    private static String seguridadSecretToken;
    private static Integer seguridadIdAplicativo;
    private static Integer seguridadTiempoExpiraSegundos;
    private static Integer seguridadTiempoRefreshSegundos;
    private static int timeoutBdTransactionSegundos;
    private static int timeoutClientApiConectionSegundos;
    private static int timeoutClientApiReadSegundos;
    private static String captchaUrl;
    private static String captchaToken;
    private static String alfrescoSupremaHost;
    private static String alfrescoSupremaPuerto;
	private static String alfrescoSupremaUsuario;
	private static String alfrescoSupremaClave;
	private static String alfrescoSupremaPath;
	private static String alfrescoSupremaVersion;
    
    @Autowired
    public ProjectProperties(
            @Value("${configuracion.seguridad.secretToken:null}") String seguridadSecretToken,
            @Value("${configuracion.seguridad.idaplicativo:0}") Integer seguridadIdAplicativo,
            @Value("${configuracion.seguridad.authenticate.token.tiempo.expira.segundos:300}") Integer seguridadTiempoExpiraSegundos,
            @Value("${configuracion.seguridad.authenticate.token.tiempo.refresh.segundos:180}") Integer seguridadTiempoRefreshSegundos,
            @Value("${timeout.database.transaction.segundos:120}") int timeoutBdTransactionSegundos,
            @Value("${timeout.client.api.conection.segundos:60}") int timeoutClientApiConectionSegundos,
            @Value("${timeout.client.api.read.segundos:60}") int timeoutClientApiReadSegundos,
    		@Value("${alfresco.cejsupremo.host:null}") String alfrescoSupremaHost,
    		@Value("${alfresco.cejsupremo.puerto:null}") String alfrescoSupremaPuerto,
    		@Value("${alfresco.cejsupremo.usuario:null}") String alfrescoSupremaUsuario,
    		@Value("${alfresco.cejsupremo.clave:null}") String alfrescoSupremaClave,
    		@Value("${alfresco.cejsupremo.path:null}") String alfrescoSupremaPath,
		    @Value("${alfresco.cejsupremo.version:null}") String alfrescoSupremaVersion)
        	 {

        ProjectProperties.seguridadSecretToken = seguridadSecretToken;
        ProjectProperties.seguridadIdAplicativo = seguridadIdAplicativo;
        ProjectProperties.seguridadTiempoExpiraSegundos = seguridadTiempoExpiraSegundos;
        ProjectProperties.seguridadTiempoRefreshSegundos = seguridadTiempoRefreshSegundos;
        ProjectProperties.timeoutBdTransactionSegundos = timeoutBdTransactionSegundos;
        ProjectProperties.timeoutClientApiConectionSegundos = timeoutClientApiConectionSegundos;
        ProjectProperties.timeoutClientApiReadSegundos = timeoutClientApiReadSegundos;
        ProjectProperties.alfrescoSupremaHost = alfrescoSupremaHost;
        ProjectProperties.alfrescoSupremaPuerto = alfrescoSupremaPuerto;
        ProjectProperties.alfrescoSupremaUsuario = alfrescoSupremaUsuario;
        ProjectProperties.alfrescoSupremaClave = alfrescoSupremaClave;
        ProjectProperties.alfrescoSupremaPath = alfrescoSupremaPath;
        ProjectProperties.alfrescoSupremaVersion = alfrescoSupremaVersion;
       
    }

	public static String getSeguridadSecretToken() {
		return seguridadSecretToken;
	}

	public static Integer getSeguridadIdAplicativo() {
		return seguridadIdAplicativo;
	}

	public static Integer getSeguridadTiempoExpiraSegundos() {
		return seguridadTiempoExpiraSegundos;
	}

	public static Integer getSeguridadTiempoRefreshSegundos() {
		return seguridadTiempoRefreshSegundos;
	}

	public static int getTimeoutBdTransactionSegundos() {
		return timeoutBdTransactionSegundos;
	}

	public static int getTimeoutClientApiConectionSegundos() {
		return timeoutClientApiConectionSegundos;
	}

	public static int getTimeoutClientApiReadSegundos() {
		return timeoutClientApiReadSegundos;
	}

	public static String getCaptchaUrl() {
		return captchaUrl;
	}

	public static String getCaptchaToken() {
		return captchaToken;
	}

	public static String getAlfrescoSupremaHost() {
		return alfrescoSupremaHost;
	}

	public static void setAlfrescoSupremaHost(String alfrescoSupremaHost) {
		ProjectProperties.alfrescoSupremaHost = alfrescoSupremaHost;
	}

	public static String getAlfrescoSupremaPuerto() {
		return alfrescoSupremaPuerto;
	}

	public static void setAlfrescoSupremaPuerto(String alfrescoSupremaPuerto) {
		ProjectProperties.alfrescoSupremaPuerto = alfrescoSupremaPuerto;
	}

	public static String getAlfrescoSupremaUsuario() {
		return alfrescoSupremaUsuario;
	}

	public static void setAlfrescoSupremaUsuario(String alfrescoSupremaUsuario) {
		ProjectProperties.alfrescoSupremaUsuario = alfrescoSupremaUsuario;
	}

	public static String getAlfrescoSupremaClave() {
		return alfrescoSupremaClave;
	}

	public static void setAlfrescoSupremaClave(String alfrescoSupremaClave) {
		ProjectProperties.alfrescoSupremaClave = alfrescoSupremaClave;
	}

	public static String getAlfrescoSupremaPath() {
		return alfrescoSupremaPath;
	}

	public static void setAlfrescoSupremaPath(String alfrescoSupremaPath) {
		ProjectProperties.alfrescoSupremaPath = alfrescoSupremaPath;
	}

	public static String getAlfrescoSupremaVersion() {
		return alfrescoSupremaVersion;
	}

	public static void setAlfrescoSupremaVersion(String alfrescoSupremaVersion) {
		ProjectProperties.alfrescoSupremaVersion = alfrescoSupremaVersion;
	}

}

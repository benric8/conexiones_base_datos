package pe.gob.pj.expedientejudicial.domain.model.suprema;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VistaCausaExpediente implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long numeroUnico;
    private Long numeroIncidente;
    private String fechaVista;
    private String fechaProgramacion;
    private String estado;
    private String sentidoFallo;
    private String nombreParte;
    private String descripcionTipoAudiencia;
    private String observacion;
}

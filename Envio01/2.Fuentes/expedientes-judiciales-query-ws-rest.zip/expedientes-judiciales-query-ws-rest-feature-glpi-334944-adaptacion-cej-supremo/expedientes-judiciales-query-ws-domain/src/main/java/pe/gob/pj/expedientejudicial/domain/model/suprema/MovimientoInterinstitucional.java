package pe.gob.pj.expedientejudicial.domain.model.suprema;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MovimientoInterinstitucional implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String fechaIngresoActo;
	private String descripcionUbicacion;
	private String sumilla;
}

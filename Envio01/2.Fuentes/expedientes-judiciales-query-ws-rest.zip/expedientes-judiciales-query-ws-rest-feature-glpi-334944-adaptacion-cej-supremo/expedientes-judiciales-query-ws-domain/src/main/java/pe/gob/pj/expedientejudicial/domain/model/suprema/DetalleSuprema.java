package pe.gob.pj.expedientejudicial.domain.model.suprema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetalleSuprema {
	 	private Long numeroUnico;
	    private Long numeroIncidente;
	    private String codigoExpediente;
	    private String instancia;
	    private String especialidad;
	    private String especialista;
	    private String procedencia;
	    private String tipoProceso;
	    private String materia;
	    private String codigoVisualizacion;
	    private String sumilla;
	    private String etapa;
	    private String estado;
	    private String ubicacion;
	    private String codigoConclusion;
	    private String fechaInicio;
	    private String codigoDistrito;
	    private String numeroProcedencia;
	    private String secretario;
	    private String recurso;
	    private String delito;
	    private String organoProcedencia;
	    private String distritoProcedencia;
	    private String indicadorDistribucion;
	    private String instanciaAnterior;
	    private String codigoMotivoIngreso;
	    private String codigoInstancia;
}

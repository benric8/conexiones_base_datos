package pe.gob.pj.expedientejudicial.domain.model.suprema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificacionExpediente {
	private Long numeroUnico;
    private Long numeroIncidente;
    private Long secuenciaNotificacion;
    private Integer anio;
    private String fechaIngreso;
    private String fechaIngresoActo;
    private String codigoDistrito;
    private String codigoProvincia;
    private String codigoInstancia;
    private String cedula;
    private String fechaDescargo;
    private String destinatario;
    private String estadoNotificacion;
    private String estado;
    private String anexos;
    private String tipoEntidadNotificadora;
    private String fechaImpresion;
    private Integer fechaImpresionDias;
    private String fechaEnvioCentral;
    private Integer fechaEnvioDias;
    private String fechaRecepcionCentral;
    private Integer fechaRecepcionDias;
    private String fechaNotificacion;
    private Integer fechaNotificacionDias;
    private String fechaDevolucion;
    private Integer fechaDevolucionDias;
    private String visualizacion;
}

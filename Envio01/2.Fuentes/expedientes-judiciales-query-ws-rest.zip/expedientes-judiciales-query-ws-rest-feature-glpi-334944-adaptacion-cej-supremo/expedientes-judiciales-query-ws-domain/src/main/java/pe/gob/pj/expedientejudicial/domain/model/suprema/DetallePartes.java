package pe.gob.pj.expedientejudicial.domain.model.suprema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetallePartes {
	private Long numeroUnico;
    private Long numeroIncidente;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String nombres;
    private String descripcionParte;
    private String tipoPersona;
    private String codigoVisualizacion;
    private String recurrente;
}

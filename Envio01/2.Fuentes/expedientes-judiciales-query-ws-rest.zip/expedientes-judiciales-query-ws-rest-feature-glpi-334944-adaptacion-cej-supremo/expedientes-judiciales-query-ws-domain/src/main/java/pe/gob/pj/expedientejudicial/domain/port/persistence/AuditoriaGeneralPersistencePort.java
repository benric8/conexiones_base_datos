package pe.gob.pj.expedientejudicial.domain.port.persistence;

import pe.gob.pj.expedientejudicial.domain.model.auditoriageneral.AuditoriaAplicativos;

public interface AuditoriaGeneralPersistencePort {
	public void crear(AuditoriaAplicativos auditoriaAplicativos) throws Exception;
}

package pe.gob.pj.expedientejudicial.domain.model.suprema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VocalPonente {
	private String codigoUsuario;
	private String nombreUsuario;
}

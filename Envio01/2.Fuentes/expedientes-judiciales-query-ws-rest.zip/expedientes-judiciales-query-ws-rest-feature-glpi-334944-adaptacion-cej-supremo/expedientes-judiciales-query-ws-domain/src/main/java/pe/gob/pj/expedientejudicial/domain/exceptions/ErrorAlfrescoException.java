package pe.gob.pj.expedientejudicial.domain.exceptions;

import lombok.Getter;

@Getter
public class ErrorAlfrescoException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String codigo;
	
	public ErrorAlfrescoException(String codigo,String message) {
	        super(message);
	        this.codigo=codigo;
	}

	public ErrorAlfrescoException(String codigo,String message, Throwable cause) {
	        super(message, cause);
	        this.codigo=codigo;
	}

}

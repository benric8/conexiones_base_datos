package pe.gob.pj.expedientejudicial.domain.model.suprema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SeguimientoExpediente {
	 	private Long numeroUnico;
	    private Long numeroIncidente;
	    private String tipoActo;
	    private String codigoVisualizacion;
	    private String fechaDescargo;
	    private String codigoTipoNotificacion;
	    private String sumilla;
	    private Integer numeroFojas;
	    private String fechaIngresoActo;
	    private String resolucion;
	    private String flagFila;
	    private String acto;
	    private String fechaIngreso;
	    private String descripcionUsuario;
	    private String conResolucion;
	    private String tipoArchivo;
	    private String conFirma;
	    private String fechaResolucion;
	    private Integer esObligatorio;
	    private Integer anioGrupoNotificacion;
	    private Long secuenciaGrupoNotificacion;
	    private String codigoOrganoJurisdiccional;
	    private String esUtilizado;
	    private String presentante;
		private String flagTramite;
}

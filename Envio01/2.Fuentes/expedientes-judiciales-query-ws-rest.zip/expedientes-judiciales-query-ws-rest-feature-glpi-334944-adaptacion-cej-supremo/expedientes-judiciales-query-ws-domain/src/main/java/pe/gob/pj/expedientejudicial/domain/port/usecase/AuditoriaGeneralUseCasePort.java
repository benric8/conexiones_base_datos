package pe.gob.pj.expedientejudicial.domain.port.usecase;

import pe.gob.pj.expedientejudicial.domain.model.auditoriageneral.AuditoriaAplicativos;

public interface AuditoriaGeneralUseCasePort {
	public void crear(String cuo, AuditoriaAplicativos auditoriaAplicativos) throws Exception;
}

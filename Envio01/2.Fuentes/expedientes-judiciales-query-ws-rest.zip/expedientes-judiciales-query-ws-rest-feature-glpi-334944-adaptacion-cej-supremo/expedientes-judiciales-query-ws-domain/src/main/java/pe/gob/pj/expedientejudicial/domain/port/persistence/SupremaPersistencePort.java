package pe.gob.pj.expedientejudicial.domain.port.persistence;

import java.util.List;

import pe.gob.pj.expedientejudicial.domain.model.suprema.DetallePartes;
import pe.gob.pj.expedientejudicial.domain.model.suprema.DetalleSuprema;
import pe.gob.pj.expedientejudicial.domain.model.suprema.HitoExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.LinkEjecutoria;
import pe.gob.pj.expedientejudicial.domain.model.suprema.MovimientoInterinstitucional;
import pe.gob.pj.expedientejudicial.domain.model.suprema.NotificacionExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.Resolucion;
import pe.gob.pj.expedientejudicial.domain.model.suprema.ResumenExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.SeguimientoExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.EjecutoriaSuprema;
import pe.gob.pj.expedientejudicial.domain.model.suprema.VistaCausaExpediente;
import pe.gob.pj.expedientejudicial.domain.model.suprema.VocalPonente;

public interface SupremaPersistencePort {
	public List<HitoExpediente> obtenerHitosExpediente(String cuo,Long numeroUnico,Integer numeroIncidente,char flagIndicador) throws Exception;
	public List<MovimientoInterinstitucional> obtenerMovimientosInterinstitucionales(String cuo,Long numeroUnico,Integer numeroIncidente) throws Exception;
	public List<ResumenExpediente> obtenerResumenExpediente(String cuo,String codigoInstancia, String codigoDistrito, 
																		String codigoProvincia, String codigoMotivoIngreso, String anioExpediente, 
																		Long numeroExpedienteSala, String anioProceso, Long numeroExpedienteProceso, 
																		String codigoDistritoProceso, String apellidoPaterno, String apellidoMaterno, 
																		String nombres) throws Exception;
	public List<DetalleSuprema> obtenerDetalleSuprema(String cuo,Long numeroUnico,Integer numeroIncidente) throws Exception;

	public List<DetallePartes> obtenerDetallePartes(String cuo,Long numeroUnico,Integer numeroIncidente) throws Exception;

	public List<VistaCausaExpediente> listarVistaCausaExp(String cuo,Long numeroUnico,Integer numeroIncidente) throws Exception;

	public List<SeguimientoExpediente> obtenerSeguimientoExpediente(String cuo,Long numeroUnico,Integer numeroIncidente) throws Exception;

	public List<NotificacionExpediente> obtenerNotificacionExpediente(String cuo,Long numeroUnico,Integer numeroIncidente, String fechaIngreso, String fechaIngresoActo) throws Exception;

	public List<VocalPonente> obtenerVocalPonente(String cuo,Long numeroUnico,Integer numeroIncidente) throws Exception;

	public LinkEjecutoria obtenerLinkEjecutoria(String cuo,Long numeroUnico,Integer numeroIncidente, String fechaDescargo) throws Exception;

	public Resolucion obtenerResolucion(String cuo,Long numeroUnico,Integer numeroIncidente, String fechaDescargo) throws Exception;
	
	public List<EjecutoriaSuprema> obtenerEjecutoriaSuprema(String cuo,Long numeroUnico,Integer numeroIncidente) throws Exception;
}

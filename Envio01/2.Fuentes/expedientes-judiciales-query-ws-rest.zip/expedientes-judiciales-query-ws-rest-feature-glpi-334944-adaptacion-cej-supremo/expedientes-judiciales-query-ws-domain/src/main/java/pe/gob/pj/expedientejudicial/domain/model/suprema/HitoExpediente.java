package pe.gob.pj.expedientejudicial.domain.model.suprema;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class HitoExpediente implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	   	private int codigoHito;
	    private String descripcionHito;
	    private int numeroOrden;
	    private String fechaHito;
	    private String descripcionTipoAudiencia;
	    private String descripcionEstado;
	    private String codigoMotivoIngreso;
	    private String descripcionMotivoIngreso;
	    private String indicadorEjecutoria;
	    private String indicadorFiscalia;
	    private String observacion;
	    private String tipoHito;
	    private String cronica;
}

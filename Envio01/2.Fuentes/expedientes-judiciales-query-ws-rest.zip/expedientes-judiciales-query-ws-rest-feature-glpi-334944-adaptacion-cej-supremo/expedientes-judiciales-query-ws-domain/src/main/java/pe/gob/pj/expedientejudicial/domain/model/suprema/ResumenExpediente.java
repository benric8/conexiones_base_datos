package pe.gob.pj.expedientejudicial.domain.model.suprema;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ResumenExpediente implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long numeroUnico;
    private Integer numeroIncidente;
    private String fechaIngresoExpediente;
    private String codigoExpediente;
    private String descripcionInstancia;
    private String descripcionDistrito;
    private String descripcionPartes;
    private String indicadorVisualizacion;
    private String codigoOrganoJurisdiccional;
    private String descripcionCuaderno;
    private String codigoMotivoIngreso;
    private String indicadorRedistribucion;
    private String codigoInstanciaAnterior;
	
}
